package ir.geoscan.mobile

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var magneticSensor: Sensor? = null
    private var baseline = 0.0
    private var calibrated = false
    private var lastMagnitude = 0.0
    private lateinit var valueText: TextView
    private lateinit var statusText: TextView
    private lateinit var baselineText: TextView
    private lateinit var scanList: LinearLayout
    private lateinit var calibrateButton: Button
    private val readings = mutableListOf<Double>()

    private val navy = Color.rgb(7, 20, 38)
    private val panel = Color.rgb(15, 36, 62)
    private val cyan = Color.rgb(56, 189, 248)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        buildUi()
        if (magneticSensor == null) {
            statusText.text = "سنسور مغناطیسی در این گوشی شناسایی نشد."
            calibrateButton.isEnabled = false
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 18); setBackgroundColor(navy) }
        val title = TextView(this).apply { text = "ژئواسکن موبایل"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        root.addView(title, lp(-1, -2))
        val subtitle = TextView(this).apply { text = "تحلیل میدان مغناطیسی | نسخه آزمایشی ۱.۰"; textSize = 13f; setTextColor(cyan); gravity = Gravity.CENTER; setPadding(0, 8, 0, 22) }
        root.addView(subtitle, lp(-1, -2))
        valueText = TextView(this).apply { text = "۰٫۰ µT"; textSize = 34f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0, 24, 0, 12) }
        root.addView(valueText, lp(-1, -2))
        statusText = TextView(this).apply { text = "در انتظار داده سنسور…"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 18) }
        root.addView(statusText, lp(-1, -2))
        baselineText = TextView(this).apply { text = "خط مبنا: ثبت نشده"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(12, 14, 12, 14); setBackgroundColor(panel) }
        root.addView(baselineText, lp(-1, -2))
        calibrateButton = button("کالیبره‌کردن در محل بدون فلز") { calibrate() }
        root.addView(calibrateButton, lp(-1, 52))
        root.addView(button("ثبت نقطه اسکن") { savePoint() }, lp(-1, 52))
        root.addView(button("پاک‌کردن نقاط ثبت‌شده") { scanList.removeAllViews(); readings.clear() }, lp(-1, 52))
        val legend = TextView(this).apply {
            text = "راهنمای رنگ نقشه (صرفاً دسته‌بندی فرضیه‌ها)\n🔵 آبی: ناهنجاری سازگار با فضای خالی؛ نیازمند سنجش مستقل\n🔴 قرمز: پاسخ احتمالی غیرآهنی؛ به معنی تشخیص طلا نیست\n🟣 بنفش: ناهنجاری مغناطیسی احتمالی آهنی\n\nتوجه: سنسور گوشی فقط میدان مغناطیسی را می‌سنجد؛ با آن نمی‌توان طلا، حفره یا آلودگی شیمیایی خاک را قطعی تشخیص داد."
            textSize = 13f; setTextColor(Color.WHITE); setPadding(14, 16, 14, 16); setBackgroundColor(panel)
        }
        root.addView(legend, lp(-1, -2).apply { topMargin = 12 })
        val label = TextView(this).apply { text = "نقاط ثبت‌شده"; setTextColor(cyan); textSize = 16f; setPadding(0, 18, 0, 6) }
        root.addView(label, lp(-1, -2))
        scanList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(scanList) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h).apply { bottomMargin = 9 }
    private fun button(text: String, action: () -> Unit) = Button(this).apply { this.text = text; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(20, 93, 145)); setOnClickListener { action() } }

    override fun onResume() { super.onResume(); magneticSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }
    override fun onPause() { super.onPause(); sensorManager.unregisterListener(this) }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_MAGNETIC_FIELD) return
        val x = event.values[0].toDouble(); val y = event.values[1].toDouble(); val z = event.values[2].toDouble()
        lastMagnitude = sqrt(x*x + y*y + z*z)
        valueText.text = String.format(Locale("fa"), "%.1f µT", lastMagnitude)
        if (calibrated) {
            val delta = kotlin.math.abs(lastMagnitude - baseline)
            statusText.text = String.format(Locale("fa"), "اختلاف با خط مبنا: %.1f µT", delta)
            statusText.setTextColor(if (delta > 8) Color.rgb(255, 120, 100) else Color.LTGRAY)
        } else statusText.text = "برای شروع، در محل نسبتاً دور از فلز کالیبره کنید."
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun calibrate() {
        if (readings.size < 5) {
            Toast.makeText(this, "چند ثانیه گوشی را ثابت نگه دارید و دوباره کالیبره کنید.", Toast.LENGTH_LONG).show()
            baseline = lastMagnitude
        } else baseline = readings.takeLast(5).average()
        calibrated = true
        baselineText.text = String.format(Locale("fa"), "خط مبنا: %.1f µT", baseline)
        Toast.makeText(this, "خط مبنا ثبت شد؛ گوشی را با جهت ثابت حرکت دهید.", Toast.LENGTH_LONG).show()
    }

    private fun savePoint() {
        if (lastMagnitude <= 0) { Toast.makeText(this, "هنوز داده‌ای از سنسور دریافت نشده است.", Toast.LENGTH_SHORT).show(); return }
        readings.add(lastMagnitude)
        val delta = if (calibrated) kotlin.math.abs(lastMagnitude - baseline) else 0.0
        val row = TextView(this).apply {
            text = String.format(Locale("fa"), "%s  |  %.1f µT  |  اختلاف %.1f µT", SimpleDateFormat("HH:mm:ss", Locale("fa")).format(Date()), lastMagnitude, delta)
            setTextColor(Color.WHITE); textSize = 13f; setPadding(10, 10, 10, 10)
            setBackgroundColor(if (calibrated && delta > 8) Color.rgb(105, 39, 46) else panel)
        }
        scanList.addView(row, lp(-1, -2))
    }
}
